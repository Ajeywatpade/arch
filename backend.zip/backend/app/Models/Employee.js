'use strict'

const Model = use('Model')

class Employee extends Model {}

module.exports = Employee
